from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

csrf = CSRFProtect()  # every POST must carry a valid CSRF token
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Please log in to continue."
