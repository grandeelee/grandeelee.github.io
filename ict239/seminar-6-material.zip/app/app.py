import os
import time

from flask import Flask, g, request, render_template
from flask_login import current_user

from extensions import csrf, login_manager
from models.cart import CartItem
from models.traffic import traffic

# Paths that should not show up in the traffic numbers (static files, the admin page polling itself)
UNTRACKED_PREFIXES = ("/assets/", "/api/admin/", "/healthz", "/favicon.ico")


def create_app():
    app = Flask(__name__, static_folder="assets", static_url_path="/assets")
    # On Cloud Run set SECRET_KEY, otherwise every container restart logs everyone out
    app.secret_key = os.environ.get("SECRET_KEY", "change-me-later")
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    csrf.init_app(app)
    login_manager.init_app(app)

    from controllers.auth import auth
    from controllers.shop import shop
    from controllers.demo import demo
    from controllers.api import api
    from controllers.admin import admin
    app.register_blueprint(auth)
    app.register_blueprint(shop)
    app.register_blueprint(api)
    app.register_blueprint(admin)
    app.register_blueprint(demo, url_prefix="/demo")

    @app.context_processor
    def inject_cart_count():
        if current_user.is_authenticated:
            return {"cart_count": CartItem.countItems(current_user)}
        return {"cart_count": 0}

    @app.get("/healthz")
    def healthz():
        return "ok"

    @app.errorhandler(403)
    def forbidden(_):
        return render_template("error.html", code=403, message="Admins only."), 403

    @app.errorhandler(404)
    def not_found(_):
        return render_template("error.html", code=404, message="Page not found."), 404

    # ---- traffic recording: runs around every request -------------------------------------
    @app.before_request
    def start_timer():
        g.start = time.perf_counter()

    @app.after_request
    def log_request(response):
        if not request.path.startswith(UNTRACKED_PREFIXES):
            ms = (time.perf_counter() - g.get("start", time.perf_counter())) * 1000
            # the route pattern (/api/products/<product_id>), so 8 products are 1 row, not 8
            route = request.url_rule.rule if request.url_rule else "(not found)"
            user = current_user.name if current_user.is_authenticated else "anonymous"
            traffic.record(route, request.method, request.path, response.status_code, ms, user)
        return response

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)), debug=True)
