from flask import Blueprint, request, redirect, url_for

demo = Blueprint("demo", __name__)  # registered with url_prefix="/demo" in app.py


@demo.route("/greet/<name>")
def greet(name):
    return f"Hello, {name}!"


@demo.route("/add/<int:a>/<int:b>")
def add(a, b):
    return str(a + b)


@demo.route("/greetWithArgs")
def greetWithArgs():
    name = request.args.get("friend", "stranger").title()
    return redirect(url_for("demo.greet", name=name))