from flask import Blueprint, jsonify, render_template

from models.product import Product
from models.store import REVENUE

api = Blueprint("api", __name__)  # endpoints become api.productDetail, api.revenue, api.revenuePage


@api.route("/api/products/<product_id>")
def productDetail(product_id):
    """One product as JSON - called by the hover popup on the shop page."""
    product = Product.getProduct(product_id)
    if not product:
        return jsonify({"error": "Product not found"}), 404
    return jsonify({
        "id": product.id,
        "name": product.name,
        "description": product.description,
        "price": product.price,
    })


@api.route("/api/revenue")
def revenue():
    """Revenue figures (SGD) from data/revenue.json - called by the charts on the revenue page."""
    return jsonify(REVENUE)


@api.route("/revenue")
def revenuePage():
    return render_template("revenue.html")
