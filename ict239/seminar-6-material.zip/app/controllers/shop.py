from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from models.product import Product
from models.cart import CartItem

shop = Blueprint("shop", __name__)  # endpoints: shop.home, shop.cart, shop.cartAdd, shop.cartRemove, shop.cartClear


def _to_float(text):
    try:
        return float(text) if text else None
    except ValueError:  # "abc" in the URL should not crash the page
        return None


@shop.route("/")
def home():
    keyword = request.args.get("keyword", "").strip() or None
    sort = request.args.get("sort") or None
    min_price = _to_float(request.args.get("min_price"))
    max_price = _to_float(request.args.get("max_price"))

    products = Product.filterProducts(keyword=keyword, min_price=min_price, max_price=max_price, sort=sort)
    return render_template(
        "shopping.html",
        products=products,
        keyword=keyword or "",
        min_price=request.args.get("min_price", ""),
        max_price=request.args.get("max_price", ""),
        sort=sort or "",
    )


@shop.route("/cart")
@login_required
def cart():
    items = CartItem.getCartItems(current_user)
    total = sum(item.subtotal for item in items)
    return render_template("cart.html", items=items, total=total)


@shop.route("/cart/add/<product_id>", methods=["POST"])
@login_required
def cartAdd(product_id):
    product = Product.getProduct(product_id)
    if not product:
        flash("Sorry, that product does not exist")
        return redirect(url_for("shop.home"))
    CartItem.addToCart(current_user, product)
    flash(f"Added {product.name} to your cart")
    return redirect(url_for("shop.home"))


@shop.route("/cart/remove/<product_id>", methods=["POST"])
@login_required
def cartRemove(product_id):
    product = Product.getProduct(product_id)
    if product:
        CartItem.removeFromCart(current_user, product)
    return redirect(url_for("shop.cart"))


@shop.route("/cart/clear", methods=["POST"])
@login_required
def cartClear():
    CartItem.clearCart(current_user)
    return redirect(url_for("shop.cart"))
