from functools import wraps
from flask import Blueprint, jsonify, render_template, abort
from flask_login import current_user, login_required

from models.traffic import traffic

admin = Blueprint("admin", __name__)  # endpoints: admin.dashboard, admin.trafficData


def admin_required(view):
    @wraps(view)
    @login_required  # not logged in -> redirected to the login page
    def wrapper(*args, **kwargs):
        if not current_user.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapper


@admin.route("/admin")
@admin_required
def dashboard():
    return render_template("admin.html")


@admin.route("/api/admin/traffic")
@admin_required
def trafficData():
    """Live numbers for the admin charts; the page polls this every 2 seconds."""
    return jsonify(traffic.snapshot())
