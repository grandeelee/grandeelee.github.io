export PYTHONPATH=.
uvicorn main:app --reload --host 0.0.0.0 --port 5000
