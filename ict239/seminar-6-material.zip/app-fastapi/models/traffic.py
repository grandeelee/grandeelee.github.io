"""In-memory request log behind the admin traffic page. Nothing is stored on disk."""
import threading
import time
from collections import Counter, deque

BUCKET_SECONDS = 5
BUCKETS = 60  # 60 x 5 s = the last 5 minutes on the line chart


class TrafficLog:
    def __init__(self, keep=2000):
        self.lock = threading.Lock()
        self.events = deque(maxlen=keep)  # newest last
        self.started = time.time()
        self.total = 0
        self.by_route = Counter()
        self.by_status = Counter()  # "2xx", "3xx", ...

    def record(self, route, method, path, status, ms, user):
        now = time.time()
        with self.lock:
            self.total += 1
            self.by_route[route] += 1
            self.by_status[f"{status // 100}xx"] += 1
            self.events.append({"t": now, "route": route, "method": method, "path": path,
                                "status": status, "ms": round(ms, 1), "user": user})

    def snapshot(self):
        now = time.time()
        with self.lock:
            events = list(self.events)
            total, started = self.total, self.started
            by_route, by_status = dict(self.by_route), dict(self.by_status)

        # requests per 5-second bucket, oldest first; errors (>= 400) counted separately
        requests = [0] * BUCKETS
        errors = [0] * BUCKETS
        for e in events:
            age = int((now - e["t"]) // BUCKET_SECONDS)
            if 0 <= age < BUCKETS:
                requests[BUCKETS - 1 - age] += 1
                if e["status"] >= 400:
                    errors[BUCKETS - 1 - age] += 1
        labels = [f"-{(BUCKETS - 1 - i) * BUCKET_SECONDS}s" for i in range(BUCKETS)]

        recent = [e for e in events if now - e["t"] <= 60]
        times = sorted(e["ms"] for e in events)
        top = sorted(by_route.items(), key=lambda kv: kv[1], reverse=True)[:8]
        return {
            "uptime": int(now - started),
            "total": total,
            "last_minute": len(recent),
            "avg_ms": round(sum(times) / len(times), 1) if times else 0,
            "p95_ms": times[max(0, -(-len(times) * 95 // 100) - 1)] if times else 0,
            "timeline": {"labels": labels, "requests": requests, "errors": errors},
            "routes": {"labels": [r for r, _ in top], "counts": [c for _, c in top]},
            "status": {k: by_status.get(k, 0) for k in ("2xx", "3xx", "4xx", "5xx")},
            "recent": [{**e, "t": time.strftime("%H:%M:%S", time.localtime(e["t"]))}
                       for e in reversed(events[-15:])],
        }


traffic = TrafficLog()
