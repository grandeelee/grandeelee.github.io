"""The 'database': JSON files read once at start-up and kept in memory.

Cloud Run containers have no disk that survives a restart, so nothing here is written back.
products.json / users.json / revenue.json are the seed data; anything created while the app
runs (new users, cart lines) lives only in these dicts until the container stops.
"""
import json
import threading
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
lock = threading.RLock()  # gunicorn runs several threads in one process


def load(name):
    with open(DATA_DIR / name, encoding="utf-8") as f:
        return json.load(f)


PRODUCTS = {p["id"]: p for p in load("products.json")}
USERS = {u["id"]: u for u in load("users.json")}
CARTS = {}  # user id -> {product id: quantity}
REVENUE = load("revenue.json")
