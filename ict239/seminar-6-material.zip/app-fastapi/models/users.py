import os
import uuid
from werkzeug.security import generate_password_hash, check_password_hash

from models.store import USERS, lock

# Optional: set ADMIN_PASSWORD on the Cloud Run service so the public admin account is not "12345"
if os.environ.get("ADMIN_PASSWORD"):
    for _u in USERS.values():
        if _u["is_admin"]:
            _u["password"] = generate_password_hash(os.environ["ADMIN_PASSWORD"])


class User:
    is_authenticated = True

    def __init__(self, data):
        self.id = data["id"]
        self.email = data["email"]
        self.name = data["name"]
        self.password = data["password"]  # the HASH, never the plain password
        self.is_admin = data.get("is_admin", False)

    @staticmethod
    def getUser(email):
        email = email.lower()
        for data in USERS.values():
            if data["email"].lower() == email:
                return User(data)
        return None

    @staticmethod
    def getUserById(user_id):
        data = USERS.get(user_id)
        return User(data) if data else None

    @staticmethod
    def createUser(email, name, password):
        with lock:
            user = User.getUser(email)
            if not user:
                data = {"id": uuid.uuid4().hex, "email": email, "name": name,
                        "password": generate_password_hash(password), "is_admin": False}
                USERS[data["id"]] = data
                user = User(data)
        return user

    def checkPassword(self, password):
        return check_password_hash(self.password, password)


class Anonymous:
    """What templates see as current_user when nobody is logged in."""
    is_authenticated = False
    is_admin = False
    name = ""
