from models.product import Product
from models.store import CARTS, lock


class CartItem:
    """One cart line. Carts live in memory: CARTS[user id][product id] = quantity."""

    def __init__(self, product, quantity):
        self.product = product
        self.quantity = quantity

    @property
    def subtotal(self):
        return self.product.price * self.quantity

    @staticmethod
    def getCartItems(user):
        lines = CARTS.get(user.id, {})
        items = [CartItem(Product.getProduct(pid), qty) for pid, qty in lines.items()]
        return [i for i in items if i.product]

    @staticmethod
    def countItems(user):
        return sum(CARTS.get(user.id, {}).values())  # total number of units in the cart

    @staticmethod
    def addToCart(user, product):
        with lock:
            lines = CARTS.setdefault(user.id, {})
            lines[product.id] = lines.get(product.id, 0) + 1

    @staticmethod
    def removeFromCart(user, product):
        with lock:
            CARTS.get(user.id, {}).pop(product.id, None)

    @staticmethod
    def clearCart(user):
        with lock:
            CARTS.pop(user.id, None)
