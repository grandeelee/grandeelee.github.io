from models.store import PRODUCTS


class Product:
    """Same static-method API as the MongoEngine version in lab 5, but backed by products.json."""

    def __init__(self, data):
        self.id = data["id"]
        self.name = data["name"]
        self.description = data["description"]
        self.price = data["price"]

    @staticmethod
    def getProduct(product_id):
        data = PRODUCTS.get(product_id)
        return Product(data) if data else None

    @staticmethod
    def getAllProducts():
        return [Product(d) for d in PRODUCTS.values()]

    @staticmethod
    def filterProducts(keyword=None, min_price=None, max_price=None, sort=None):
        results = Product.getAllProducts()
        if keyword:
            kw = keyword.lower()
            results = [p for p in results if kw in p.name.lower() or kw in p.description.lower()]
        if min_price is not None:
            results = [p for p in results if p.price >= min_price]
        if max_price is not None:
            results = [p for p in results if p.price <= max_price]

        if sort == "price_asc":
            results.sort(key=lambda p: p.price)
        elif sort == "price_desc":
            results.sort(key=lambda p: p.price, reverse=True)
        else:
            results.sort(key=lambda p: p.name.lower())  # name is the default order
        return results
