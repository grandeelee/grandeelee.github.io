"""Small helpers that Flask + Flask-Login + Flask-WTF gave us for free in the Flask version."""
import secrets
from urllib.parse import quote

from fastapi import Depends, HTTPException, Request
from fastapi.templating import Jinja2Templates

from models.cart import CartItem
from models.users import User, Anonymous

templates = Jinja2Templates(directory="templates")


class LoginRedirect(Exception):
    """Raised by login_required; main.py turns it into a redirect to /login?next=..."""
    def __init__(self, next_url):
        self.next_url = next_url


# ---- session helpers ---------------------------------------------------------------------
def flash(request: Request, message: str):
    request.session.setdefault("_flashes", []).append(message)


def csrf_token(request: Request) -> str:
    if "csrf" not in request.session:
        request.session["csrf"] = secrets.token_hex(16)
    return request.session["csrf"]


async def verify_csrf(request: Request):
    """Dependency for every POST route: the form must carry the token stored in the session."""
    form = await request.form()
    sent = form.get("csrf_token", "")
    expected = request.session.get("csrf", "")
    if not expected or not secrets.compare_digest(str(sent), expected):
        raise HTTPException(400, "Invalid or missing CSRF token")


# ---- current user -----------------------------------------------------------------------
def get_current_user(request: Request):
    user_id = request.session.get("user_id")
    return (User.getUserById(user_id) if user_id else None) or Anonymous()


def login_required(request: Request, user=Depends(get_current_user)):
    if not user.is_authenticated:
        flash(request, "Please log in to continue.")
        raise LoginRedirect(request.url.path)
    return user


def admin_required(user=Depends(login_required)):
    if not user.is_admin:
        raise HTTPException(403, "Admins only.")
    return user


# ---- templates --------------------------------------------------------------------------
def _url_for(request: Request):
    def url_for(name, **params):
        """Same call style as Flask templates: url_for('shop.cartAdd', product_id=...)."""
        if name == "static":
            return "/assets/" + params["filename"]
        return request.app.url_path_for(name, **params)  # a relative path: safe behind Cloud Run's proxy
    return url_for


def render(request: Request, name: str, status_code: int = 200, **context):
    user = get_current_user(request)
    flashes = request.session.pop("_flashes", [])
    context.update(
        current_user=user,
        cart_count=CartItem.countItems(user) if user.is_authenticated else 0,
        csrf_token=lambda: csrf_token(request),
        get_flashed_messages=lambda: flashes,
        url_for=_url_for(request),
    )
    return templates.TemplateResponse(request, name, context, status_code=status_code)
