from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from core import render
from models.product import Product
from models.store import REVENUE

router = APIRouter()  # route names: api.productDetail, api.revenue, api.revenuePage


@router.get("/api/products/{product_id}", name="api.productDetail")
async def productDetail(product_id: str):
    """One product as JSON - called by the hover popup on the shop page."""
    product = Product.getProduct(product_id)
    if not product:
        return JSONResponse({"error": "Product not found"}, status_code=404)
    return {"id": product.id, "name": product.name, "description": product.description, "price": product.price}


@router.get("/api/revenue", name="api.revenue")
async def revenue():
    """Revenue figures (SGD) from data/revenue.json."""
    return REVENUE


@router.get("/revenue", name="api.revenuePage")
async def revenuePage(request: Request):
    return render(request, "revenue.html")
