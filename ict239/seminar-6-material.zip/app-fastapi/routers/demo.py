from fastapi import APIRouter
from fastapi.responses import PlainTextResponse, RedirectResponse

router = APIRouter(prefix="/demo")  # prefix given here instead of in register_blueprint


@router.get("/greet/{name}", name="demo.greet", response_class=PlainTextResponse)
async def greet(name: str):
    return f"Hello, {name}!"


@router.get("/add/{a}/{b}", name="demo.add", response_class=PlainTextResponse)
async def add(a: int, b: int):  # int in the signature = Flask's <int:a>; "abc" gives a 422 error
    return str(a + b)


@router.get("/greetWithArgs", name="demo.greetWithArgs")
async def greetWithArgs(friend: str = "stranger"):  # query-string argument, default "stranger"
    return RedirectResponse(f"/demo/greet/{friend.title()}")
