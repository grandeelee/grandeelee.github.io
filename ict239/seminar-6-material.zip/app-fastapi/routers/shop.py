from typing import Optional
from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse

from core import render, flash, verify_csrf, login_required
from models.product import Product
from models.cart import CartItem

router = APIRouter()  # route names: shop.home, shop.cart, shop.cartAdd, shop.cartRemove, shop.cartClear


def redirect(url):
    return RedirectResponse(url, status_code=303)


def _to_float(text: Optional[str]):
    try:
        return float(text) if text else None
    except ValueError:  # "abc" in the URL should not crash the page
        return None


@router.get("/", name="shop.home")
async def home(request: Request):
    q = request.query_params
    keyword = q.get("keyword", "").strip() or None
    sort = q.get("sort") or None
    products = Product.filterProducts(keyword=keyword, min_price=_to_float(q.get("min_price")),
                                      max_price=_to_float(q.get("max_price")), sort=sort)
    return render(request, "shopping.html", products=products, keyword=keyword or "",
                  min_price=q.get("min_price", ""), max_price=q.get("max_price", ""), sort=sort or "")


@router.get("/cart", name="shop.cart")
async def cart(request: Request, user=Depends(login_required)):
    items = CartItem.getCartItems(user)
    total = sum(item.subtotal for item in items)
    return render(request, "cart.html", items=items, total=total)


@router.post("/cart/add/{product_id}", name="shop.cartAdd", dependencies=[Depends(verify_csrf)])
async def cartAdd(product_id: str, request: Request, user=Depends(login_required)):
    product = Product.getProduct(product_id)
    if not product:
        flash(request, "Sorry, that product does not exist")
        return redirect("/")
    CartItem.addToCart(user, product)
    flash(request, f"Added {product.name} to your cart")
    return redirect("/")


@router.post("/cart/remove/{product_id}", name="shop.cartRemove", dependencies=[Depends(verify_csrf)])
async def cartRemove(product_id: str, user=Depends(login_required)):
    product = Product.getProduct(product_id)
    if product:
        CartItem.removeFromCart(user, product)
    return redirect("/cart")


@router.post("/cart/clear", name="shop.cartClear", dependencies=[Depends(verify_csrf)])
async def cartClear(user=Depends(login_required)):
    CartItem.clearCart(user)
    return redirect("/cart")
