from urllib.parse import urlsplit
from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse

from core import render, flash, verify_csrf, get_current_user
from models.forms import LoginForm, RegisterForm
from models.users import User

router = APIRouter()  # route names mirror the Flask endpoints: auth.login, auth.register, auth.logout


def redirect(url):
    return RedirectResponse(url, status_code=303)  # 303 = "now GET this", the right answer after a POST


@router.get("/login", name="auth.login")
async def login_page(request: Request, user=Depends(get_current_user)):
    if user.is_authenticated:
        return redirect("/")
    return render(request, "login.html", form=LoginForm())


@router.post("/login", dependencies=[Depends(verify_csrf)])
async def login_submit(request: Request):
    form = LoginForm(formdata=await request.form())
    if form.validate():
        user = User.getUser(form.email.data)
        if not user:
            form.email.errors.append("Email not found")
        elif not user.checkPassword(form.password.data):
            form.password.errors.append("Password incorrect")
        else:
            request.session["user_id"] = user.id
            flash(request, f"Welcome back, {user.name}!")
            next_page = request.query_params.get("next")
            if not next_page or urlsplit(next_page).netloc or not next_page.startswith("/"):
                next_page = "/"  # reject absolute URLs
            return redirect(next_page)
    return render(request, "login.html", form=form)


@router.get("/register", name="auth.register")
async def register_page(request: Request):
    return render(request, "register.html", form=RegisterForm())


@router.post("/register", dependencies=[Depends(verify_csrf)])
async def register_submit(request: Request):
    form = RegisterForm(formdata=await request.form())
    if form.validate():
        if User.getUser(form.email.data):
            form.email.errors.append("Email already registered")
        else:
            User.createUser(form.email.data, form.name.data, form.password.data)
            flash(request, "Account created - please log in")
            return redirect(request.app.url_path_for("auth.login"))
    return render(request, "register.html", form=form)


@router.get("/logout", name="auth.logout")
async def logout(request: Request):
    request.session.pop("user_id", None)
    flash(request, "You have been logged out")
    return redirect("/")
