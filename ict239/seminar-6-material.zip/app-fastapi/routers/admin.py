from fastapi import APIRouter, Depends, Request

from core import render, admin_required
from models.traffic import traffic

router = APIRouter(dependencies=[Depends(admin_required)])  # every route here is admins-only


@router.get("/admin", name="admin.dashboard")
async def dashboard(request: Request):
    return render(request, "admin.html")


@router.get("/api/admin/traffic", name="admin.trafficData")
async def trafficData():
    """Live numbers for the admin charts; the page polls this every 2 seconds."""
    return traffic.snapshot()
