import os
import time

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.sessions import SessionMiddleware

from urllib.parse import quote

from core import LoginRedirect, render, get_current_user
from models.traffic import traffic
from routers import auth, shop, api, admin, demo

# Paths that should not show up in the traffic numbers (static files, the admin page polling itself)
UNTRACKED_PREFIXES = ("/assets/", "/api/admin/", "/healthz", "/favicon.ico")

app = FastAPI(title="Essentials shop")
app.mount("/assets", StaticFiles(directory="assets"), name="static")
for module in (auth, shop, api, admin, demo):
    app.include_router(module.router)


@app.get("/healthz", include_in_schema=False)
async def healthz():
    return PlainTextResponse("ok")


# ---- error pages -------------------------------------------------------------------------
@app.exception_handler(LoginRedirect)
async def to_login(request: Request, exc: LoginRedirect):
    return RedirectResponse(f"{request.app.url_path_for('auth.login')}?next={quote(exc.next_url)}", status_code=303)


@app.exception_handler(StarletteHTTPException)
async def http_error(request: Request, exc: StarletteHTTPException):
    if request.url.path.startswith("/api/"):  # AJAX callers get JSON, browsers get a page
        from fastapi.responses import JSONResponse
        return JSONResponse({"error": exc.detail}, status_code=exc.status_code)
    return render(request, "error.html", status_code=exc.status_code, code=exc.status_code, message=exc.detail)


@app.exception_handler(RequestValidationError)
async def bad_input(request: Request, exc: RequestValidationError):
    return render(request, "error.html", status_code=422, code=422, message="That URL has an invalid value.")


# ---- traffic recording: runs around every request -----------------------------------------
@app.middleware("http")
async def record_traffic(request: Request, call_next):
    start = time.perf_counter()
    status = 500  # if call_next raises, the visitor sees a 500
    try:
        response = await call_next(request)
        status = response.status_code
        return response
    finally:
        path = request.url.path
        if not path.startswith(UNTRACKED_PREFIXES):
            route = request.scope.get("route")
            # the route pattern (/api/products/{product_id}), so 8 products are 1 row, not 8
            pattern = getattr(route, "path", None) or "(not found)"
            user = get_current_user(request)
            traffic.record(pattern, request.method, path, status,
                           (time.perf_counter() - start) * 1000, user.name if user.is_authenticated else "anonymous")


# Added last = outermost, so request.session already exists inside the middleware above.
# On Cloud Run set SECRET_KEY, otherwise every container restart logs everyone out.
app.add_middleware(SessionMiddleware, secret_key=os.environ.get("SECRET_KEY", "change-me-later"),
                   same_site="lax", max_age=14 * 24 * 3600)
