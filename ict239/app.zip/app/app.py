from app import app
from flask_login import current_user
from models.cart import CartItem
from controllers.auth import auth
from controllers.shop import shop
from controllers.demo import demo

# Register the blueprints so Flask knows about their routes
app.register_blueprint(auth)
app.register_blueprint(shop)
app.register_blueprint(demo, url_prefix="/demo")  # /demo/greet/<name>, /demo/add/2/3, ...


@app.context_processor
def inject_cart_count():
    # Runs before every template is rendered. The dict it returns becomes template variables,
    # so base.html can show {{ cart_count }} without every route passing it in.
    if current_user.is_authenticated:
        return {"cart_count": CartItem.countItems(current_user)}
    return {"cart_count": 0}