from flask_login import UserMixin
from mongoengine.errors import ValidationError
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager


class User(UserMixin, db.Document):  # UserMixin adds is_authenticated, get_id() etc.
    meta = {"collection": "users"}
    email = db.StringField(required=True, unique=True)
    name = db.StringField(required=True)
    password = db.StringField(required=True)  # stores the HASH, never the plain password

    @staticmethod
    def getUser(email):
        return User.objects(email=email).first()  # None if not found

    @staticmethod
    def getUserById(user_id):
        try:
            return User.objects(pk=user_id).first()
        except ValidationError:  # user_id is not a valid ObjectId
            return None

    @staticmethod
    def createUser(email, name, password):
        user = User.getUser(email)
        if not user:
            user = User(email=email, name=name, password=generate_password_hash(password))
            user.save()
        return user

    def checkPassword(self, password):
        return check_password_hash(self.password, password)  # True / False


@login_manager.user_loader
def load_user(user_id):
    # Flask-Login calls this on every request, with the id it stored in the session cookie.
    return User.getUserById(user_id)