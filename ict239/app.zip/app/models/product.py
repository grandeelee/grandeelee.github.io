from mongoengine import Q
from mongoengine.errors import ValidationError
from app import db


class Product(db.Document):
    meta = {"collection": "products"}
    name = db.StringField(required=True, max_length=60)
    description = db.StringField(max_length=300)
    price = db.FloatField(required=True, min_value=0)

    @staticmethod
    def getProduct(product_id):
        try:
            return Product.objects(pk=product_id).first()
        except ValidationError:
            return None

    @staticmethod
    def getAllProducts():
        return Product.objects()

    @staticmethod
    def createProduct(name, description, price):
        return Product(name=name, description=description, price=price).save()

    @staticmethod
    def getByPriceRange(min_price=None, max_price=None):
        filters = {}
        if min_price is not None:
            filters["price__gte"] = min_price
        if max_price is not None:
            filters["price__lte"] = max_price
        return Product.objects(**filters)

    @staticmethod
    def _applySort(queryset, sort):
        sort_map = {
            "price_asc": "price",
            "price_desc": "-price",
            "name_asc": "name",
        }
        return queryset.order_by(sort_map.get(sort, "name"))  # "name" is the default order

    @staticmethod
    def search(keyword):
        return Product.objects(Q(name__icontains=keyword) | Q(description__icontains=keyword))

    @staticmethod
    def filterProducts(keyword=None, min_price=None, max_price=None, sort=None):
        query = Q()
        if keyword:
            query &= (Q(name__icontains=keyword) | Q(description__icontains=keyword))
        if min_price is not None:
            query &= Q(price__gte=min_price)
        if max_price is not None:
            query &= Q(price__lte=max_price)

        results = Product.objects(query)
        return Product._applySort(results, sort)