from app import db
from models.users import User
from models.product import Product


class CartItem(db.Document):
    meta = {"collection": "cart_items"}
    user = db.ReferenceField(User, required=True)        # whose cart this line belongs to
    product = db.ReferenceField(Product, required=True)  # which product
    quantity = db.IntField(default=1, min_value=1)

    @property
    def subtotal(self):
        return self.product.price * self.quantity

    @staticmethod
    def getCartItems(user):
        return CartItem.objects(user=user)

    @staticmethod
    def getCartItem(user, product):
        return CartItem.objects(user=user, product=product).first()  # None if not in the cart

    @staticmethod
    def countItems(user):
        return CartItem.objects(user=user).sum("quantity")  # total number of units in the cart

    @staticmethod
    def addToCart(user, product):
        item = CartItem.getCartItem(user, product)
        if item:
            item.quantity += 1  # already in the cart: one more
        else:
            item = CartItem(user=user, product=product)
        return item.save()

    @staticmethod
    def removeFromCart(user, product):
        item = CartItem.getCartItem(user, product)
        if item:
            item.delete()
        return item

    @staticmethod
    def clearCart(user):
        CartItem.objects(user=user).delete()

    @staticmethod
    def filterCart(user, min_price=None, max_price=None):
        product_filters = {}
        if min_price is not None:
            product_filters["price__gte"] = min_price
        if max_price is not None:
            product_filters["price__lte"] = max_price

        if product_filters:
            matching_products = Product.objects(**product_filters)
            return CartItem.objects(user=user, product__in=matching_products)
        return CartItem.objects(user=user)

    @staticmethod
    def getCartItemsSorted(user, sort=None):
        items = list(CartItem.getCartItems(user))
        if sort == "price_asc":
            items.sort(key=lambda i: i.product.price)
        elif sort == "price_desc":
            items.sort(key=lambda i: i.product.price, reverse=True)
        elif sort == "subtotal_desc":
            items.sort(key=lambda i: i.subtotal, reverse=True)
        return items