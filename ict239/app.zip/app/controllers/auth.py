from urllib.parse import urlsplit
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, current_user

from models.forms import LoginForm, RegisterForm
from models.users import User

auth = Blueprint("auth", __name__)  # endpoints become auth.login, auth.register, auth.logout


@auth.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("shop.home"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.getUser(form.email.data)
        if not user:
            form.email.errors.append("Email not found")
        elif not user.checkPassword(form.password.data):
            form.password.errors.append("Password incorrect")
        else:
            login_user(user, remember=form.remember_me.data)
            flash(f"Welcome back, {user.name}!")
            next_page = request.args.get("next")
            if not next_page or urlsplit(next_page).netloc:  # reject absolute URLs
                next_page = url_for("shop.home")
            return redirect(next_page)
    return render_template("login.html", form=form)


@auth.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if User.getUser(form.email.data):
            form.email.errors.append("Email already registered")
        else:
            User.createUser(form.email.data, form.name.data, form.password.data)
            flash("Account created - please log in")
            return redirect(url_for("auth.login"))
    return render_template("register.html", form=form)


@auth.route("/logout")
def logout():
    logout_user()
    flash("You have been logged out")
    return redirect(url_for("shop.home"))