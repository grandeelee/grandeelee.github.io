from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from models.product import Product
from models.cart import CartItem

shop = Blueprint("shop", __name__)  # endpoints: shop.home, shop.cart, shop.cartAdd, shop.cartRemove, shop.cartClear


@shop.route("/")
def home():
    """Insert the sample catalogue the first time the shop is opened, then list the products."""
    if Product.objects.count() == 0:  # only when the collection is empty - carts point at these products
        samples = [
            ("Linen Shirt", "Breathable, relaxed fit.", 79.0),
            ("Canvas Tote", "Sturdy everyday bag.", 35.5),
            ("Ceramic Mug", "Hand-glazed, 350 ml.", 18.0),
            ("Wool Beanie", "Soft merino blend.", 24.9),
            ("Leather Wallet", "Slim, full-grain leather.", 55.0),
            ("Cotton Socks (3 pack)", "Everyday crew socks.", 15.0),
            ("Desk Lamp", "Warm light, adjustable arm.", 48.0),
            ("Notebook", "A5, 120 pages, dotted.", 9.5),
        ]
        for name, description, price in samples:
            Product.createProduct(name, description, price)
    keyword = request.args.get("keyword", "").strip() or None
    sort = request.args.get("sort") or None

    min_price = request.args.get("min_price")
    min_price = float(min_price) if min_price else None

    max_price = request.args.get("max_price")
    max_price = float(max_price) if max_price else None

    products = Product.filterProducts(keyword=keyword, min_price=min_price, max_price=max_price, sort=sort)
    return render_template(
        "shopping.html",
        products=products,
        keyword=keyword or "",
        min_price=request.args.get("min_price", ""),
        max_price=request.args.get("max_price", ""),
        sort=sort or "",
    )


@shop.route("/cart")
@login_required
def cart():
    items = CartItem.getCartItems(current_user)
    total = sum(item.subtotal for item in items)
    return render_template("cart.html", items=items, total=total)


@shop.route("/cart/add/<product_id>", methods=["POST"])
@login_required
def cartAdd(product_id):
    product = Product.getProduct(product_id)
    if not product:
        flash("Sorry, that product does not exist")
        return redirect(url_for("shop.home"))
    CartItem.addToCart(current_user, product)
    flash(f"Added {product.name} to your cart")
    return redirect(url_for("shop.home"))


@shop.route("/cart/remove/<product_id>", methods=["POST"])
@login_required
def cartRemove(product_id):
    product = Product.getProduct(product_id)
    if product:
        CartItem.removeFromCart(current_user, product)
    return redirect(url_for("shop.cart"))


@shop.route("/cart/clear", methods=["POST"])
@login_required
def cartClear():
    CartItem.clearCart(current_user)
    return redirect(url_for("shop.cart"))