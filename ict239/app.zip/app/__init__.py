from flask import Flask
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_mongoengine import MongoEngine


def create_app():
    app = Flask(__name__)
    app.static_folder = "assets"
    app.secret_key = "change-me-later"
    app.config["MONGODB_SETTINGS"] = [
        {
            "db": "shop",
            "host": "localhost",
            "port": 27017,
        }
    ]
    db = MongoEngine(app)

    CSRFProtect(app)  # every POST must carry a valid CSRF token

    login_manager = LoginManager(app)
    login_manager.login_view = "auth.login"      # was "login"
    login_manager.login_message = "Please log in to continue."
    return app, db, login_manager


app, db, login_manager = create_app()